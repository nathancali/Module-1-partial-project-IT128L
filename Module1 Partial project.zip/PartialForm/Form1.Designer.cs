﻿namespace PartialForm
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            dataGridView1 = new DataGridView();
            button2 = new Button();
            nameTextBox = new TextBox();
            codeTextBox = new TextBox();
            brandTextBox = new TextBox();
            unitPriceTextBox = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            button3 = new Button();
            Idtextbox = new TextBox();
            label5 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(537, 107);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 1;
            button1.Text = "Display";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.AllowUserToOrderColumns = true;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Dock = DockStyle.Bottom;
            dataGridView1.Location = new Point(0, 166);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.RowTemplate.Height = 29;
            dataGridView1.Size = new Size(684, 217);
            dataGridView1.TabIndex = 2;
            // 
            // button2
            // 
            button2.Location = new Point(12, 17);
            button2.Name = "button2";
            button2.Size = new Size(95, 46);
            button2.TabIndex = 3;
            button2.Text = "Add";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click_1;
            // 
            // nameTextBox
            // 
            nameTextBox.Location = new Point(113, 36);
            nameTextBox.Name = "nameTextBox";
            nameTextBox.Size = new Size(125, 27);
            nameTextBox.TabIndex = 5;
            nameTextBox.TextChanged += textBox1_TextChanged;
            // 
            // codeTextBox
            // 
            codeTextBox.CharacterCasing = CharacterCasing.Lower;
            codeTextBox.Location = new Point(244, 36);
            codeTextBox.Name = "codeTextBox";
            codeTextBox.Size = new Size(125, 27);
            codeTextBox.TabIndex = 6;
            // 
            // brandTextBox
            // 
            brandTextBox.Location = new Point(375, 36);
            brandTextBox.Name = "brandTextBox";
            brandTextBox.Size = new Size(125, 27);
            brandTextBox.TabIndex = 7;
            // 
            // unitPriceTextBox
            // 
            unitPriceTextBox.Location = new Point(506, 36);
            unitPriceTextBox.Name = "unitPriceTextBox";
            unitPriceTextBox.Size = new Size(125, 27);
            unitPriceTextBox.TabIndex = 8;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(153, 9);
            label1.Name = "label1";
            label1.Size = new Size(49, 20);
            label1.TabIndex = 9;
            label1.Text = "Name";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(279, 9);
            label2.Name = "label2";
            label2.Size = new Size(44, 20);
            label2.TabIndex = 10;
            label2.Text = "Code";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(413, 9);
            label3.Name = "label3";
            label3.Size = new Size(48, 20);
            label3.TabIndex = 11;
            label3.Text = "Brand";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(524, 9);
            label4.Name = "label4";
            label4.Size = new Size(72, 20);
            label4.TabIndex = 12;
            label4.Text = "Unit Price";
            // 
            // button3
            // 
            button3.Location = new Point(13, 87);
            button3.Name = "button3";
            button3.Size = new Size(94, 47);
            button3.TabIndex = 13;
            button3.Text = "Delete";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // Idtextbox
            // 
            Idtextbox.Location = new Point(113, 107);
            Idtextbox.Name = "Idtextbox";
            Idtextbox.Size = new Size(125, 27);
            Idtextbox.TabIndex = 14;
            Idtextbox.TextChanged += textBox1_TextChanged_1;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(163, 84);
            label5.Name = "label5";
            label5.Size = new Size(24, 20);
            label5.TabIndex = 15;
            label5.Text = "ID";
            label5.Click += label5_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(684, 383);
            Controls.Add(label5);
            Controls.Add(Idtextbox);
            Controls.Add(button3);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(unitPriceTextBox);
            Controls.Add(brandTextBox);
            Controls.Add(codeTextBox);
            Controls.Add(nameTextBox);
            Controls.Add(button2);
            Controls.Add(dataGridView1);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private DataGridView dataGridView1;
        private Button button2;
        private TextBox nameTextBox;
        private TextBox codeTextBox;
        private TextBox brandTextBox;
        private TextBox unitPriceTextBox;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Button button3;
        private TextBox Idtextbox;
        private Label label5;
    }
}