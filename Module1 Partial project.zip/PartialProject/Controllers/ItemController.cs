﻿using Microsoft.AspNetCore.Mvc;
using PartialProject.Models;

[ApiController]
[Route("[controller]")]
public class ItemController : ControllerBase
{
    private readonly ILogger<ItemController> _logger;

    public ItemController(ILogger<ItemController> logger)
    {
        _logger = logger;
    }

    // Static field to store items
    private static List<Item> _items = new List<Item>()
    {
        new Item { Id = 1, Name = "Item 1", Code = "001", Brand = "Brand A", UnitPrice = 10.99m },
        new Item { Id = 2, Name = "Item 2", Code = "002", Brand = "Brand B", UnitPrice = 20.99m },
        new Item { Id = 3, Name = "Item 3", Code = "003", Brand = "Brand C", UnitPrice = 30.99m }
    };

    [HttpGet]
    public IEnumerable<Item> Get()
    {
        return _items;
    }

    // GET: api/items/1
    [HttpGet("{id}")]
    public ActionResult<Item> GetItem(int id)
    {
        var item = _items.FirstOrDefault(i => i.Id == id);
        if (item == null)
        {
            return NotFound();
        }
        return item;
    }

    // POST: api/items
    [HttpPost]
    public IActionResult AddItem([FromBody] Item newItem)
    {
        newItem.Id = _items.Count + 1;
        _items.Add(newItem);
        return Ok(newItem);
    }



// PUT: api/items/1
[HttpPut("{id}")]
    public IActionResult UpdateItem(int id, [FromBody] Item item)
    {
        var existingItem = _items.FirstOrDefault(i => i.Id == id);
        if (existingItem == null)
        {
            return NotFound();
        }
        existingItem.Name = item.Name;
        existingItem.Code = item.Code;
        existingItem.Brand = item.Brand;
        existingItem.UnitPrice = item.UnitPrice;
        return NoContent();
    }

    // DELETE: api/items/1
    [HttpDelete("{id}")]
    public IActionResult DeleteItem(int id)
    {
        var itemToRemove = _items.FirstOrDefault(i => i.Id == id);
        if (itemToRemove == null)
        {
            return NotFound();
        }

        _items.Remove(itemToRemove);
        return NoContent();
    }

}