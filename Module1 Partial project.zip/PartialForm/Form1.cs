using RestSharp;
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using PartialProject.Models;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace PartialForm
{
    public partial class Form1 : Form
    {
        private const string BaseUrl = "https://localhost:7120/Item";
        private List<Item> _items = new List<Item>();
        public Form1()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            LoadItems();
        }

        private void LoadItems()
        {
            var client = new RestClient("https://localhost:7120/Item");
            var request = new RestRequest(Method.GET);
            var response = client.Execute<List<Item>>(request);

            if (response.IsSuccessful)
            {
                dataGridView1.DataSource = response.Data;
            }
            else
            {
                MessageBox.Show("Failed to load items", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LoadItems();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            // Validate textboxes
            if (string.IsNullOrWhiteSpace(nameTextBox.Text) || string.IsNullOrWhiteSpace(codeTextBox.Text) || string.IsNullOrWhiteSpace(brandTextBox.Text) || string.IsNullOrWhiteSpace(unitPriceTextBox.Text))
            {
                MessageBox.Show("Please enter all fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            decimal unitPrice;
            if (!decimal.TryParse(unitPriceTextBox.Text, out unitPrice))
            {
                MessageBox.Show("Please enter a valid unit price.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Item newItem = new Item
            {
                Name = nameTextBox.Text,
                Code = codeTextBox.Text,
                Brand = brandTextBox.Text,
                UnitPrice = decimal.Parse(unitPriceTextBox.Text)
            };

            // Call the AddItem API method using RestSharp
            var client = new RestClient("https://localhost:7120/Item");
            var request = new RestRequest(Method.POST);
            request.AddJsonBody(newItem);
            var response = client.Execute(request);

            if (response.IsSuccessful)
            {
                // Reload items in data grid view
                LoadItems();
                MessageBox.Show("Item added successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Failed to add item.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Validate ID textbox
            if (string.IsNullOrWhiteSpace(Idtextbox.Text))
            {
                MessageBox.Show("Please enter an ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            int id;
            if (!int.TryParse(Idtextbox.Text, out id))
            {
                MessageBox.Show("Please enter a valid ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Call the DeleteItem API method using RestSharp
            var client = new RestClient($"https://localhost:7120/Item/{id}");
            var request = new RestRequest(Method.DELETE);
            var response = client.Execute(request);

            if (response.IsSuccessful)
            {
                // Reload items in data grid view
                LoadItems();
                MessageBox.Show("Item deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Failed to delete item.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }


    }
}
